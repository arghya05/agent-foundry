"""Phase 0 — core contracts every layer of Agent Foundry plugs into.

See PLAN.md for the architecture these types implement.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Any, Callable, Protocol, TypedDict


# ---- Identity & policy (Identity & Governance rail) ------------------------

@dataclass(frozen=True)
class Identity:
    """Who is running this call: an agent, a sub-agent, or a human operator."""
    id: str
    tenant_id: str
    roles: tuple[str, ...] = ()


class AutonomyLevel(IntEnum):
    """Graduated autonomy, L0-L5 — replaces a binary approve/deny with how much a
    tool call is allowed to happen without a human in the loop."""
    L0_ANSWER = 0          # no action at all — respond only
    L1_RECOMMEND = 1       # may suggest an action, never take it
    L2_DRAFT = 2           # may prepare a non-destructive action; destructive ones still blocked
    L3_APPROVAL = 3        # may execute, but requires_approval tools still need a human (default)
    L4_POLICY_BOUND = 4    # may execute anything Policy allows, no per-call approval
    L5_FULL_AUTONOMY = 5   # same ceiling as L4 — the distinction is operational trust, not code


class AgentRole(str, Enum):
    """A light taxonomy over AgentConfig — used by build_debate_graph to find the
    judge, and by a builder to document what a specialist is for."""
    GENERALIST = "generalist"
    SPECIALIST = "specialist"
    SUPERVISOR = "supervisor"
    WORKER = "worker"
    VERIFIER = "verifier"


@dataclass
class Policy:
    """What an identity is allowed to do, and what it's allowed to spend."""
    allowed_tools: frozenset[str] = field(default_factory=frozenset)
    max_cost_usd_per_thread: float = 1.0
    max_steps_per_thread: int = 25
    requires_approval: frozenset[str] = field(default_factory=frozenset)
    autonomy: AutonomyLevel = AutonomyLevel.L3_APPROVAL


# ---- Tools Gateway -----------------------------------------------------------

@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: dict[str, Any]  # JSON schema
    fn: Callable[..., Any]
    destructive: bool = False  # True => goes through the action guardrail / HITL
    # Everything below is additive (all defaulted) — existing positional/keyword
    # construction (`ToolSpec(name, description, parameters, fn)` or with
    # `destructive=`) is unaffected.
    version: str = "1.0.0"
    scopes: frozenset[str] = field(default_factory=frozenset)
    requires_confirmation: bool = False
    cacheable: bool = True  # only consulted by ToolRegistry.invoke() when NOT destructive — see tools_gateway.py
    idempotent: bool = False
    timeout_s: float | None = None  # per-tool override of AgentConfig.step_timeout_s
    max_retries: int = 0
    data_classification: str = "internal"  # public | internal | confidential | restricted
    output_schema: dict[str, Any] | None = None
    # The hosts THIS tool is declared to reach, known at registration time
    # (e.g. http_tool() derives it from its own URL template) — not derived
    # from a specific call's args, which vary per call and have no
    # generically reliable "this is the host" field. Checked against
    # policy_engine.PolicyDecisionPoint's egress policy on every call; empty
    # (default) means this tool has no egress dimension for the PDP to check.
    egress_hosts: frozenset[str] = field(default_factory=frozenset)
    # Informational metadata for a caller's OWN RBAC check before registering
    # this tool into Policy.allowed_tools — not enforced by ToolRegistry.invoke()
    # itself (that's still the existing name-based allowed_tools allowlist).
    # Set by core.tool_decorator.tool()'s permissions= kwarg and by
    # agent_spec.build_agent()'s structured tool entries.
    permissions: frozenset[str] = field(default_factory=frozenset)


@dataclass
class ToolResult:
    tool: str
    ok: bool
    output: Any = None
    error: str | None = None
    latency_ms: float = 0.0


# ---- LLM Gateway ---------------------------------------------------------------

class Message(TypedDict, total=False):
    """The shape every message dict in this codebase already has,
    structurally — AgentState.messages, LLMResponse-building code,
    ToolRegistry results, every test fixture. Purely a documentation-level
    type: a TypedDict is erased at runtime, so this changes no behavior —
    every existing `{"role": ..., "content": ...}` literal already
    satisfies it. `total=False` (not NotRequired-per-field, to avoid a
    typing_extensions dependency for this package's Python 3.10 floor)
    since only `role`/`content` are truly always present in practice, and
    this type is never used for runtime validation anyway."""

    role: str
    content: Any
    tool_call_id: str
    tool_calls: list[dict[str, Any]]
    ok: bool


@dataclass
class ToolCall:
    """One native, structured tool call the model chose to make — real
    provider-native tool-calling (Anthropic/OpenAI tool_use blocks), not a text
    convention parsed after the fact."""
    id: str
    name: str
    args: dict[str, Any]


@dataclass
class LLMResponse:
    text: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    tool_calls: list[ToolCall] = field(default_factory=list)


class Provider(Protocol):
    def complete(self, messages: list[dict], *, model: str, tools: list[dict] | None = None, **kw: Any) -> LLMResponse: ...


# `Model` is the same Protocol as `Provider`, under the name a reader
# reaches for first — AnthropicProvider/OpenAIProvider/MultiProvider
# (llm_gateway.py) are Model implementations by either name. Not a rewrite:
# `Provider` stays the primary name throughout llm_gateway.py/tests (real
# rename would be pure churn), this is the public-facing alias.
Model = Provider


# ---- Guardrails ------------------------------------------------------------------

@dataclass
class GuardrailResult:
    allowed: bool
    reason: str | None = None
    stage: str = ""  # input | output | action | runtime
    escalate: bool = False  # True: hand off to a human/other agent (escalation.py) instead of a flat deny
    requires_approval: bool = False  # Explicit approval request; a denial's wording never grants override authority.


# ---- Eval --------------------------------------------------------------------------

@dataclass
class EvalRecord:
    level: str  # atomic | component | flow | overall
    unit: str  # tool name, node name, or thread id
    metric: str
    score: float  # 0..1
    detail: dict[str, Any] = field(default_factory=dict)
    ts: float = field(default_factory=time.time)
