"""Core — StateStore implementations. See protocols.StateStore's own
docstring for the shape/scope contract (3 sync methods, why it's sync).

MemoryStateStore is the in-process reference implementation — not a
drop-in replacement for anything native_engine.py already does on its own
(NativeEngine keeps its own in-process `self._threads` cache regardless of
which store, if any, sits underneath it — see NativeEngine's own docstring).
It exists so the seam itself is real and verifiable
(`isinstance(MemoryStateStore(), StateStore)` — proof the same way
core.engines.RUNTIMES proved WorkflowEngine was a real seam before
Agent.__init__ was wired through it).

PostgresStateStore is the real cross-restart backend with no existing
sibling convention in this repo to follow (no psycopg/sqlalchemy usage
anywhere else) — see RedisStateStore in distributed.py (that module's own
established home for every other Redis-backed swappable primitive) for the
other real backend. Both are wired the identical way: `Agent(...,
runtime="native", state_store=<either one>)`.
"""
from __future__ import annotations

import copy
import json
import threading
from typing import Any


class MemoryStateStore:
    """The in-process reference implementation — literally the same shape
    NativeEngine._threads already keeps (one dict per run_id), just exposed
    as a standalone StateStore instead of private to that one engine.
    save()/load() deep-copy (not just the top-level dict — state here nests
    a list of message dicts) so a caller mutating what load() returned, or
    later mutating the object it passed to save(), can never reach back into
    this store's own storage — the same guarantee a real Redis/Postgres
    backend gets for free from serializing on the way in and out. No
    persistence across a process restart — that's what RedisStateStore/
    PostgresStateStore are for."""

    def __init__(self) -> None:
        self._states: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()

    def load(self, run_id: str) -> dict[str, Any] | None:
        with self._lock:
            state = self._states.get(run_id)
            return copy.deepcopy(state) if state is not None else None

    def save(self, run_id: str, state: dict[str, Any]) -> None:
        with self._lock:
            self._states[run_id] = copy.deepcopy(state)

    def delete(self, run_id: str) -> None:
        with self._lock:
            self._states.pop(run_id, None)


class PostgresStateStore:
    """core.protocols.StateStore, Postgres-backed. `pip install
    agent-foundry[postgres]` (`psycopg2-binary`, lazily imported — not a
    base dependency). One table, created on first use if missing (`CREATE
    TABLE IF NOT EXISTS`, not a migration system — this is a 3-method
    key/value contract, not a schema with relationships): `run_id TEXT
    PRIMARY KEY, state JSONB`. `save()` is `INSERT ... ON CONFLICT (run_id)
    DO UPDATE` — an upsert, matching MemoryStateStore's own "save overwrites
    a previous save for the same run_id" contract exactly (see
    tests/test_state_store.py's own contract tests, run against this class
    too).

    A real ThreadedConnectionPool backs this, not one shared connection —
    ThreadedConnectionPool is psycopg2's own thread-safe pool variant (unlike
    plain SimpleConnectionPool), so getconn()/putconn() need no lock of ours
    on top: concurrent calls for DIFFERENT run_ids get genuinely different
    connections and run in real parallel against Postgres, instead of
    queuing behind one Python-level lock the way an earlier version of this
    class did. `minconn`/`maxconn` bound how many real Postgres connections
    this ever opens — size `maxconn` to your actual concurrency, not
    unboundedly (Postgres itself has a connection ceiling). Call `close()`
    when you're done with this store (process shutdown, end of a test) to
    release every pooled connection — the pool doesn't do this for you on
    garbage collection the way a single connection object more casually
    might."""

    def __init__(
        self, *, dsn: str = "dbname=agent_foundry", table: str = "agent_foundry_state", minconn: int = 1, maxconn: int = 10,
    ):
        from psycopg2 import sql
        from psycopg2.pool import ThreadedConnectionPool

        self._table_ident = sql.Identifier(table)  # never f-string a table name into raw SQL — table= is caller-supplied
        self._pool = ThreadedConnectionPool(minconn, maxconn, dsn)
        conn = self._pool.getconn()
        try:
            conn.autocommit = True
            with conn.cursor() as cur:
                cur.execute(sql.SQL("CREATE TABLE IF NOT EXISTS {} (run_id TEXT PRIMARY KEY, state JSONB NOT NULL)").format(self._table_ident))
        finally:
            self._pool.putconn(conn)

    def close(self) -> None:
        self._pool.closeall()

    def load(self, run_id: str) -> dict[str, Any] | None:
        from psycopg2 import sql

        conn = self._pool.getconn()
        try:
            conn.autocommit = True
            with conn.cursor() as cur:
                cur.execute(sql.SQL("SELECT state FROM {} WHERE run_id = %s").format(self._table_ident), (run_id,))
                row = cur.fetchone()
        finally:
            self._pool.putconn(conn)
        return None if row is None else (row[0] if isinstance(row[0], dict) else json.loads(row[0]))

    def save(self, run_id: str, state: dict[str, Any]) -> None:
        from psycopg2 import sql

        conn = self._pool.getconn()
        try:
            conn.autocommit = True
            with conn.cursor() as cur:
                cur.execute(
                    sql.SQL("INSERT INTO {} (run_id, state) VALUES (%s, %s) ON CONFLICT (run_id) DO UPDATE SET state = EXCLUDED.state")
                    .format(self._table_ident),
                    (run_id, json.dumps(state)),
                )
        finally:
            self._pool.putconn(conn)

    def delete(self, run_id: str) -> None:
        from psycopg2 import sql

        conn = self._pool.getconn()
        try:
            conn.autocommit = True
            with conn.cursor() as cur:
                cur.execute(sql.SQL("DELETE FROM {} WHERE run_id = %s").format(self._table_ident), (run_id,))
        finally:
            self._pool.putconn(conn)
